
const express = require('express');
const { body } = require('express-validator');
const {
  createEmployee, getEmployees, updateEmployee, deleteEmployee
} = require('../controllers/employeeController');
const auth = require('../middlewares/authMiddleware');
const validate = require('../middlewares/validate');

const router = express.Router();

const empValidation = [
  body('name').notEmpty(),
  body('email').isEmail(),
  body('position').notEmpty(),
  body('salary').isNumeric()
];

router.use(auth);
router.post('/', empValidation, validate, createEmployee);
router.get('/', getEmployees);
router.put('/:id', empValidation, validate, updateEmployee);
router.delete('/:id', deleteEmployee);

module.exports = router;
