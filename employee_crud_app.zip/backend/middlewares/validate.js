
const { validationResult } = require('express-validator');

module.exports = (req, res, next) => {
  const err = validationResult(req);
  if (!err.isEmpty()) {
    return res.status(422).json({ errors: err.array() });
  }
  next();
};
