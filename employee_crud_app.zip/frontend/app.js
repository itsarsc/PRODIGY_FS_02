
const BASE_URL = 'http://localhost:5000/api';
let token = '';

const api = async (endpoint, method = 'GET', data = null) => {
  const options = {
    method,
    headers: { 'Content-Type': 'application/json' }
  };
  if (token) options.headers.Authorization = `Bearer ${token}`;
  if (data) options.body = JSON.stringify(data);
  const res = await fetch(`${BASE_URL}${endpoint}`, options);
  return res.json();
};

document.getElementById('login-form').onsubmit = async (e) => {
  e.preventDefault();
  const creds = {
    username: document.getElementById('username').value,
    password: document.getElementById('password').value
  };
  const res = await api('/auth/login', 'POST', creds);
  if (res.token) {
    token = res.token;
    document.getElementById('login-form').style.display = 'none';
    document.getElementById('employee-section').style.display = 'block';
    loadEmployees();
  } else {
    alert('Invalid credentials');
  }
};

document.getElementById('emp-form').onsubmit = async (e) => {
  e.preventDefault();
  const emp = {
    name: document.getElementById('name').value,
    position: document.getElementById('position').value,
    email: document.getElementById('email').value,
    salary: +document.getElementById('salary').value
  };
  await api('/employees', 'POST', emp);
  e.target.reset();
  loadEmployees();
};

async function loadEmployees() {
  const employees = await api('/employees');
  const list = document.getElementById('emp-list');
  list.innerHTML = '';
  employees.forEach(emp => {
    const li = document.createElement('li');
    li.innerHTML = `${emp.name} (${emp.position}) - ₹${emp.salary}`;
    list.appendChild(li);
  });
}
